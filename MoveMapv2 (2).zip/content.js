// const queryString = window.location.search;
// const urlParams = new URLSearchParams(queryString);
// var movemap=urlParams.get("movemap")
// if(movemap)
// {
// 	localStorage.setItem('mapIDS', movemap);
// 	window.location = "about:blank";
// }